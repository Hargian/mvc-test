<div class="container">
    <div class="row" >
<div class="post-title margin-top-70">
    <h1>Login</h1>
</div>
<div class="row margin-top-30">
    <div class="col-md-12">

        <div class="row">
            <form action="login" method="post">

                <div class="col-sm-6">
                    <div class="form-group">
                        <input type="text" id="username" name="username" class="form-control" placeholder="Введите логин">
                    </div>
                </div>

                <div class="col-sm-6">
                    <div class="form-group">
                        <input type="password" id="password" name="password" class="form-control" placeholder="Введите пароль">
                    </div>
                </div>

                <div class="text-center">
                    <button type="submit" class="load-more-button">Send</button>
                </div>

            </form>
        </div>
    </div>
</div>
</div>
</div>
